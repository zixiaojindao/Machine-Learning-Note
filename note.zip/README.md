Machine Learing course note.
